﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tour
{
    public class TourOperator
    { 
      private string nextClientCode;          // variabili per il codice
        char carCode;
        int numCode;
        Dictionary<string, Client> dizionario = new Dictionary<string, Client>();           //creo il dizionario
        public TourOperator(string initialClientCode)       //costruttore che prende in input stringa del codice iniziale
        {
            string appoffio;
            nextClientCode = initialClientCode;
            carCode = nextClientCode[0];
            appoggio = nextClientCode[1].ToString() + nextClientCode[2].ToString() + nextClientCode[3].ToString();//divido stringa parte dei num e dei caratteri per quando 
            //dovrò incrementare
            numCode = Convert.ToInt32(appoggio);
        }
        public void add(string nome, string dest)       //aggiungo elementi al dizionario
        {
            Client cliente = new Client(nome, dest);
            dizionario.Add(nextClientCode, cliente);
            incrementoCode();

        }
        private void incrementoCode()           // incremento del codice
        {
            int tmp;
            if (numCode < 999)
                numCode++;
            else
            {
                numCode = 0;
                tmp = carCode;
                tmp++;
                carCode = Convert.ToChar(tmp);

            }
            nextClientCode = carCode + numCode.ToString();
        }
        public string toString()        //metodo per la visualizzazione degli elementi
        {
            string tmp = "";
            if (dizionario.Count > 0)
                foreach (KeyValuePair<string, Client> key in dizionario)
                    tmp += key.Key + ":" + key.Value.ToString() + "\n";
            else throw new Exception();
            return tmp;   //ritorna valori dentro dizionario
        }
        public static void Main(string[] args)
        {
            string tmp;
            string[] tmp2;              
            TourOperator tour;
            bool ok = false;
            do //controllo se codice iniziale inserito è corretto se no lo deve rimettere
            {

                Console.WriteLine("Inserisci il codice iniziale, del formato %Cnnn%");

                tmp = Console.ReadLine();
                if (tmp.Length == 4)
                    if (char.IsUpper(tmp[0]) && char.IsDigit(tmp[1]) && char.IsDigit(tmp[2]) && char.IsDigit(tmp[3]))
                    {
                        ok = true;                  // instazio il TourOperator
                    }
                    else
                        Console.WriteLine("Rispettare il formato %Cnnn%");
                else
                    Console.WriteLine("Rispettare il formato %Cnnn%");
            } while (ok == false);

            tour = new TourOperator(tmp);
            while (true)
            {
                Console.WriteLine("Cosa vuoi fare?");
                Console.WriteLine("[1]Inserisci");                  //chiedo cosa si voglia fare in un while
                Console.WriteLine("[2]visualizza");
                tmp = Console.ReadLine();
                switch (tmp)
                {
                    case "1":
                        Console.WriteLine("Inserisci il nome e destinazione con formato %nome:destinazione%");
                        tmp = Console.ReadLine();                   // case 1 : inserimento
                        try //controllo se la stringa è stata messa nel giusto formato
                        {
                            tmp2 = tmp.Split(':');
                            tour.add(tmp2[0], tmp2[1]); 
                        }
                        catch
                        {
                            Console.WriteLine("Rispettare il formato %nome:destinazione%");
                        }

                        break;
                    case "2":
                        try //se elementi sono dentro al dizionario
                        {
                            Console.WriteLine(tour.toString());
                        }
                        catch                                      //case 2 : visualizza
                        {
                            Console.WriteLine("Nessun elemento presente");
                        }
                        break;

                }

            }



        }
        // classi interne
        private class Client
        {
            String name; // nome del cliente
            String dest; // destinazione del viaggio
            public Client(String aName, String aDest)
            {
                name = aName;
                dest = aDest;
            }
            public override string ToString() //ridefinisco metodo to string
            {
                return name + ":" + dest;
            }
        }
        private class Coppia /*implements Comparable*/
        {
            String code;
            Client client;
            Coppia(String aCode, Client aClient)
            {
                code = aCode;
                client = aClient;
            }
            //public int compareTo(Object obj)  
            //{
            //}
        }
    }
}
